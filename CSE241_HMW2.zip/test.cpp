#include<iostream>
#include<string>
#include<fstream>
#include "hexGame.h"
#include<sstream>

using namespace std;

int main(){

	Game();

	return 0;
}