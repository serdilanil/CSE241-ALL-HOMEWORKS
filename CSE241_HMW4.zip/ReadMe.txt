Have a good, healthy day, sir.
I will explain some points that need to be explained in my homework.

-Firstly , I used Cell *hexCells as Cell **board in class in line 28 in private data.
And I used dynamic array , I've never used a vector anywhere.

-First of all, with the game, you enter all the information you want, accompanied by instructions.
-Then, the game continues until either side wins.
-After the winning condition is fulfilled, the menu appears again and if you want to continue playing, you continue to play the way you want.
-At the same time, after each winning condition is fulfilled, the total number of moves made by the users is printed on the terminal.
-In addition, there are ready games saved in the files. You can continue those game modes by typing LOAD save.txt and LOAD save2.txt. 
-save.txt(user vs user game mod), save2.txt(user vs AI mod).

-You can also use a new feature, undo, by writing the word "undo" (please,write in lowercase letters) in the terminal.

-As another new feature, I wrote a function that returns a score. Thus, for each move, users will score by move ,and the score will appear in the terminal.

-I use explicit in Hex constructor.

-I use nullptr Hex constructor and resize function. 

-I have defined 5 games in test.cpp to play 5 games at the same time as desired.

-In addition, I organized my functions according to the desired rules.
-And I explained other important explanations in Header and cpp files.

Have a good, healthy day again, sir.