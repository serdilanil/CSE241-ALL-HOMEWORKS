Have a good and healthy day Sir,

- I create  2 new concrete classes and 1 new templated this class represent the boards in different ways.
- These concrete classes are HexVector and HexArray1D also template class is HexAdapter class and HexAdapter.
- I create deque and vector in HexAdapter class you can see in test cpp .
- Also I consist game with deque and vector game for HexAdapter class you can see menu.
- I create the global function for determine invalid and valid input about 'x','o','.' and returned true or false.
- If table has only 'x','o','.' characters global function return true and write valid in terminal otherwise return false and write invalid in terminal.

- I create my own namespace in AbstractHex class.
- I create the throw exceptions in test.cpp
- I create the menu for class types(Hexvector,HexArray1D,HexAdapter(vector,deque))and if you want to exit  press number '5' selection.

-Please do not select the game type you selected once in the menu because the last game you played remains saved and does not come empty
So choose the game types differently in the menu, for example play Hexvector then play Hexadapter then play HexArray1D ...


-To compare two games, you have to 'exit' after completing the two last games you want. After selecting the Exit option, it will show whether the two last games you played are equal or not.(please complete these games and exit.)

-save.txt and save3.txt are user vs user mod save2.txt is computer vs user mod.


Thank You sir ,and have a good and healthy day again.