Have a good day Sir, I will explain my homework in this file.

-First of all, with the game, you enter all the information you want, accompanied by instructions.
-Then, the game continues until either side wins.
-After the winning condition is fulfilled, the menu appears again and if you want to continue playing, you continue to play the way you want.
-At the same time, after each winning condition is fulfilled, the total number of moves made by the users is printed on the terminal.
-I have listed 5 games in a row for you to play and you can play in the mode and table size you want.
-I wrote all the other information about the game in cpp and library file.
-In addition, there are ready games saved in the files. You can continue those game modes by typing LOAD save.txt and LOAD save2.txt. 
-save.txt(user vs user game mod), save2.txt(user vs AI mod).

-Have a good day again Sir.