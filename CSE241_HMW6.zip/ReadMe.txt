Have a good and healty day sir,

I test the codes and methods in main.java.

I create the javadoc folder for javadoc files.

Have a good and healthy day sir again.