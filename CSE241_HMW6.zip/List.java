
public interface List<T> extends Collection<T> {

    void insertAt(T elem,int indexAt);
}
