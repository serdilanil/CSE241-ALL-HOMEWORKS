public interface Set<T> extends Collection<T> {


}
