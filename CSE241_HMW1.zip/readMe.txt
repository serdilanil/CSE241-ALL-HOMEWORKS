//Sir, my problem is not a error, it's just a small bug.
//In User 1 vs User 2 game, if user 2's first move is an A6 B6 F6 style move, he will directly count the 2nd player to win.
//So This problem is only valid for "USER2" and only for the "FIRST MOVE". Other moves are ok.
//And The game works flawlessly.